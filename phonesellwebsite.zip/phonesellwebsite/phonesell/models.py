from django.db import models

# Create your models here.

class Brand(models.Model):
    name = models.CharField(max_length=100)
    
    def __str__(self) -> str:
        return self.name
    
class Phone(models.Model):
    name = models.CharField(max_length=100)
   
    def __str__(self) -> str:
        return self.name
    
class Review(models.Model):
    name = models.CharField(max_length=100)
    phone = models.ForeignKey(Phone, on_delete=models.CASCADE)
    rating = models.IntegerField()
    price   = models.FloatField(null=True)
    date_posted = models.DateTimeField(auto_now_add=True)    
    image = models.ImageField(null=True)

    def __str__(self) -> str:
        return self.name