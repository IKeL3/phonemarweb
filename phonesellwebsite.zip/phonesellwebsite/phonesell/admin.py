from django.contrib import admin
from phonesell.models import *

# Register your models here.
admin.site.register(Brand)

admin.site.register(Phone)

admin.site.register(Review)