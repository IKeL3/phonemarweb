from django.shortcuts import render, HttpResponse
from .models import *
# Create your views here.

def home(request):
    phone = Review.objects.all()
    data = {
        'phone': phone
    }
    return render(request, 'home.html', data)


def about(request):
    return render(request, 'about.html')


def contact_page(request):
    return render(request, 'contact.html')


def phonesell(request):
    phone = Review.objects.all()
    data = {
        'phone': phone
    }
    return render(request, 'phonesell.html', data)